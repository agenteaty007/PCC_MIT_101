/*
Tech198.cpp
Author: Alberto Tam Yong
Date: 25 November 2013
*/

#include <Arduino.h>
#include <Tech198.h>

Tech198::Tech198(int pin0, int pin1, int pin2, int pin3)
{
	pinMode(pin0,OUTPUT);
	pinMode(pin1,OUTPUT);
	pinMode(pin2,OUTPUT);
	pinMode(pin3,OUTPUT);
	
	_pin0 = pin0;
	_pin1 = pin1;
	_pin2 = pin2;
	_pin3 = pin3;
}

void Tech198::motor(int motorSelect, int motorDirection, int motorSpeed)
{
	_motorSelect = motorSelect;
	_motorDirection = motorDirection;
	_motorSpeed = motorSpeed;
	
	_spikePause = 50;
	
	if(_motorSelect == 0)
	{
		if(_motorDirection == 0)
		{
			digitalWrite(_pin0,0);
			digitalWrite(_pin1,0);
			delay(_spikePause);
			analogWrite(_pin0,_motorSpeed);
		}
		else if(_motorDirection == 1)
		{
			digitalWrite(_pin0,0);
			digitalWrite(_pin1,0);
			delay(_spikePause);
			analogWrite(_pin1,_motorSpeed);
		}
	}
	else if(_motorSelect == 1)
	{
		if(_motorDirection == 0)
		{
			digitalWrite(_pin2,0);
			digitalWrite(_pin3,0);
			delay(_spikePause);
			analogWrite(_pin2,_motorSpeed);
		}
		else if(_motorDirection == 1)
		{
			digitalWrite(_pin2,0);
			digitalWrite(_pin3,0);
			delay(_spikePause);
			analogWrite(_pin3,_motorSpeed);
		}
	}
}