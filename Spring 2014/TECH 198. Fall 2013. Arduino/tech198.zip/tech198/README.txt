How to Use Tech198 Library to Arduino IDE

Installing the Library
1. Unzip the Tech198 file
2. Find the folder where the Arduino IDE software was installed, and locate the "libraries" folder inside.
3. Copy the Tech198 file to the "libraries" folder.
4. Open the Arduino software.
5. On the top left corner, go to File>>Examples and verify that "Tech198" is on the options.


Demo
1. Open the Arduino software.
2. On the top left corner, go to File>>Examples>>Tech198>>Tech198_demo.
3. Click on the "Tech198_demo" file.
4. Make sure the robot is off.
5. Upload the code to the Arduino UNO and verify that the motors run.
6. Turn on the robot.
7. The robot will start to swivel.
8. Read the comments on the demo code to get familiar with the structure of the library.

For any further questions, email alberto.tam.yong@gmail.com.