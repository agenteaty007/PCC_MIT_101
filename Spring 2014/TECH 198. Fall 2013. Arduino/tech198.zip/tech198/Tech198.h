/*
Tech198.h
Author: Alberto Tam Yong
Date: 25 November 2013
*/

#ifndef Tech198_h
#define Tech198_h

#include <Arduino.h>

class Tech198
{
	public:
		Tech198(int pin0, int pin1, int pin2, int pin3);
		void motor(int motorSelect, int motorDirection, int motorSpeed);
	private:
		int _pin0;
		int _pin1;
		int _pin2;
		int _pin3;
		int _motorSelect;
		int _motorDirection;
		int _motorSpeed;
		int _spikePause;
};

#endif